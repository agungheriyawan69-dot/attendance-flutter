class Constants {
  static const int qrDurationSeconds = 90;
  static const int resetHistoryMonths = 6;
}
