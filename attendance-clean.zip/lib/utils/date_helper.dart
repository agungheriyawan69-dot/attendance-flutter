class DateHelper {
  static bool isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  static bool isOlderThanMonths(DateTime date, int months) {
    final now = DateTime.now();
    final diffMonths = (now.year - date.year) * 12 + (now.month - date.month);
    return diffMonths >= months;
  }
}
