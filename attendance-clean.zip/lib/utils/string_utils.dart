// lib/utils/string_utils.dart
const int MAX_NIM_LENGTH = 15;
const int MIN_NIM_LENGTH = 8;
const int MAX_SESSION_ID_LENGTH = 50;
const int QR_EXPIRY_SECONDS = 90;

String normalizeClassName(String input) {
  if (input.isEmpty) return '';
  return input.trim().replaceAll(RegExp(r'\s+'), ' ');
}

String normalizeNim(String input) {
  if (input.isEmpty) return '';
  return input.trim().toUpperCase();
}