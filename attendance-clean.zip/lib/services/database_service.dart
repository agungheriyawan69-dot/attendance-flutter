// lib/services/database_service.dart
import 'dart:collection';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class DatabaseService {
  // --- Static storage ---
  static final Map<String, List<Map<String, dynamic>>> _studentsByClass = HashMap();
  static final Map<String, List<Map<String, dynamic>>> _sessionsByClass = HashMap();
  static final Map<String, List<Map<String, dynamic>>> _attendanceByClassSession = HashMap();

  // --- SharedPreferences instance ---
  SharedPreferences? _prefs;

  // --- Keys ---
  static const String _KEY_STUDENTS = 'db_students_v2';
  static const String _KEY_SESSIONS = 'db_sessions_v2';
  static const String _KEY_ATTENDANCE = 'db_attendance_v2';

  // --- Inisialisasi ---
  Future<void> _ensureInitialized() async {
    if (_prefs != null) return;
    _prefs = await SharedPreferences.getInstance();
    await _loadFromPrefs();
  }

  Future<void> _loadFromPrefs() async {
    if (_prefs == null) return;

    // Load students
    final studentsJson = _prefs!.getString(_KEY_STUDENTS);
    if (studentsJson != null) {
      try {
        final map = jsonDecode(studentsJson) as Map<String, dynamic>;
        _studentsByClass.clear();
        map.forEach((className, list) {
          _studentsByClass[className] = List<Map<String, dynamic>>.from(list);
        });
      } catch (_) {}
    }

    // Load sessions
    final sessionsJson = _prefs!.getString(_KEY_SESSIONS);
    if (sessionsJson != null) {
      try {
        final map = jsonDecode(sessionsJson) as Map<String, dynamic>;
        _sessionsByClass.clear();
        map.forEach((className, list) {
          _sessionsByClass[className] = List<Map<String, dynamic>>.from(list);
        });
      } catch (_) {}
    }

    // Load attendance
    final attendanceJson = _prefs!.getString(_KEY_ATTENDANCE);
    if (attendanceJson != null) {
      try {
        final map = jsonDecode(attendanceJson) as Map<String, dynamic>;
        _attendanceByClassSession.clear();
        map.forEach((key, list) {
          _attendanceByClassSession[key] = List<Map<String, dynamic>>.from(list);
        });
      } catch (_) {}
    }
  }

  Future<void> _saveToPrefs() async {
    if (_prefs == null) return;

    final studentsMap = <String, dynamic>{};
    _studentsByClass.forEach((k, v) => studentsMap[k] = v);
    await _prefs!.setString(_KEY_STUDENTS, jsonEncode(studentsMap));

    final sessionsMap = <String, dynamic>{};
    _sessionsByClass.forEach((k, v) => sessionsMap[k] = v);
    await _prefs!.setString(_KEY_SESSIONS, jsonEncode(sessionsMap));

    final attendanceMap = <String, dynamic>{};
    _attendanceByClassSession.forEach((k, v) => attendanceMap[k] = v);
    await _prefs!.setString(_KEY_ATTENDANCE, jsonEncode(attendanceMap));
  }

  // ===== ENROLLMENT =====
  Future<void> insertStudent(String nim, String name, String className) async {
    await _ensureInitialized();
    final list = _studentsByClass.putIfAbsent(className, () => []);
    if (list.any((s) => s['nim'] == nim)) return;
    list.add({'nim': nim, 'name': name});
    await _saveToPrefs();
  }

  Future<List<Map<String, dynamic>>> getStudents(String className) async {
    await _ensureInitialized();
    return List<Map<String, dynamic>>.from(_studentsByClass[className] ?? []);
  }

  Future<void> deleteStudent(String className, String nim) async {
    await _ensureInitialized();
    final list = _studentsByClass[className];
    if (list != null) {
      list.removeWhere((s) => s['nim'] == nim);
      await _saveToPrefs();
    }
  }

  // ===== SESSIONS =====
  Future<void> createSession(String className, String sessionId, {DateTime? createdAt}) async {
    await _ensureInitialized();
    final list = _sessionsByClass.putIfAbsent(className, () => []);
    if (list.any((s) => s['sessionId'] == sessionId)) return;
    list.add({
      'sessionId': sessionId,
      'createdAt': (createdAt ?? DateTime.now()).toIso8601String(),
    });
    await _saveToPrefs();
  }

  Future<List<Map<String, dynamic>>> getSessions(String className) async {
    await _ensureInitialized();
    final raw = _sessionsByClass[className] ?? [];
    final list = List<Map<String, dynamic>>.from(raw);
    list.sort((a, b) {
      final dateA = DateTime.tryParse(a['createdAt'] ?? '') ?? DateTime.now();
      final dateB = DateTime.tryParse(b['createdAt'] ?? '') ?? DateTime.now();
      return dateB.compareTo(dateA);
    });
    return list;
  }

  Future<String?> resolveClassBySession(String sessionId) async {
    await _ensureInitialized();
    for (final entry in _sessionsByClass.entries) {
      if (entry.value.any((s) => s['sessionId'] == sessionId)) {
        return entry.key;
      }
    }
    return null;
  }

  // ===== ATTENDANCE =====
  Future<void> insertAttendance({
    required String className,
    required String sessionId,
    required String nim,
    String? name,
  }) async {
    await _ensureInitialized();
    final sessions = _sessionsByClass[className] ?? [];
    if (!sessions.any((s) => s['sessionId'] == sessionId)) return;
    final students = _studentsByClass[className] ?? [];
    final student = students.firstWhere((s) => s['nim'] == nim, orElse: () => {'nim': nim, 'name': name ?? 'Unknown'});
    final key = '$className|$sessionId';
    final list = _attendanceByClassSession.putIfAbsent(key, () => []);
    if (list.any((a) => a['nim'] == nim)) return;
    list.add({
      'nim': nim,
      'name': name ?? student['name'],
      'timestamp': DateTime.now().toIso8601String(),
    });
    await _saveToPrefs();
  }

  Future<List<Map<String, dynamic>>> getAttendance(String className, String sessionId) async {
    await _ensureInitialized();
    final key = '$className|$sessionId';
    return List<Map<String, dynamic>>.from(_attendanceByClassSession[key] ?? []);
  }

  Future<void> cleanOldAttendance(String className, {int days = 30}) async {
    await _ensureInitialized();
    final cutoff = DateTime.now().subtract(Duration(days: days));
    _attendanceByClassSession.forEach((key, list) {
      if (key.startsWith('$className|')) {
        list.removeWhere((a) {
          final ts = DateTime.tryParse(a['timestamp'] ?? '');
          return ts != null && ts.isBefore(cutoff);
        });
      }
    });
    await _saveToPrefs();
  }

  Future<List<Map<String, dynamic>>> getAttendanceRecords(String className) async {
    await _ensureInitialized();
    final records = <Map<String, dynamic>>[];
    _attendanceByClassSession.forEach((key, list) {
      if (key.startsWith('$className|')) {
        final sessionId = key.split('|')[1];
        for (final a in list) {
          final ts = DateTime.tryParse(a['timestamp'] ?? '1970-01-01T00:00:00Z');
          final date = ts != null
              ? '${ts.day.toString().padLeft(2, '0')}-${ts.month.toString().padLeft(2, '0')}-${ts.year}'
              : '01-01-1970';
          final time = ts != null
              ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}:${ts.second.toString().padLeft(2, '0')}'
              : '00:00:00';
          records.add({
            'className': className,
            'sessionId': sessionId,
            'nim': a['nim'] ?? 'UNKNOWN',
            'name': a['name'] ?? 'TANPA NAMA',
            'date': date,
            'time': time,
          });
        }
      }
    });
    return records;
  }

  Future<void> deleteSessionAndAttendance(String className, String sessionId) async {
    await _ensureInitialized();
    final sessionList = _sessionsByClass[className];
    if (sessionList != null) {
      sessionList.removeWhere((s) => s['sessionId'] == sessionId);
    }
    _attendanceByClassSession.remove('$className|$sessionId');
    await _saveToPrefs();
  }
}