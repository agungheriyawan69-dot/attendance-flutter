// lib/services/qr_service.dart
import 'dart:convert';

class QRService {
  static const int durationSeconds = 90;

  static String generateForStudent({
    required String classId,
    required String nim,
    required String name,
    required String sessionId,
  }) {
    final expiresAt = DateTime.now().add(Duration(seconds: durationSeconds));
    final payload = {
      'type': 'attendance',
      'class_id': classId,
      'nim': nim,
      'name': name,
      'session_id': sessionId,
      'expires_at_ms': expiresAt.millisecondsSinceEpoch,
    };
    final jsonString = jsonEncode(payload);
    return 'ATTENDANCE_JSON:$jsonString';
  }

  static Map<String, dynamic>? parseAttendanceQR(String rawValue) {
    if (rawValue.startsWith('ATTENDANCE_JSON:')) {
      try {
        final jsonPart = rawValue.substring('ATTENDANCE_JSON:'.length);
        final data = jsonDecode(jsonPart) as Map<String, dynamic>;
        if (data['type'] != 'attendance') return null;
        final expiryMs = data['expires_at_ms'] as int?;
        if (expiryMs == null || DateTime.now().millisecondsSinceEpoch > expiryMs) {
          return null;
        }
        return data;
      } catch (e) {
        return null;
      }
    }
    return null;
  }
}