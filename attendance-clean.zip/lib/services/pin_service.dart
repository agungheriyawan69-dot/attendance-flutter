// lib/services/pin_service.dart
import 'dart:collection';
import 'package:shared_preferences/shared_preferences.dart';

class PinService {
  PinService._();
  static final PinService _instance = PinService._();
  static PinService get instance => _instance;

  SharedPreferences? _prefs;

  // ✅ Struktur baru: simpan LIST kelas per PIN
  final Map<String, List<String>> _pinToClasses = HashMap();
  final Map<String, String> _classToPin = HashMap();

  static const String _KEY_PIN_MAP = 'pin_service_pin_to_classes_v3';
  static const String _KEY_CLASS_MAP = 'pin_service_class_to_pin_v3';

  Future<void> _ensureInitialized() async {
    if (_prefs != null) return;
    _prefs = await SharedPreferences.getInstance();
    await _loadFromPrefs();
  }

  Future<void> _loadFromPrefs() async {
    if (_prefs == null) return;

    // Load pin -> classes (pakai StringList seperti versi lama)
    final pinList = _prefs!.getStringList(_KEY_PIN_MAP) ?? [];
    _pinToClasses.clear();
    for (int i = 0; i < pinList.length; i += 2) {
      final pin = pinList[i];
      final className = pinList[i + 1];
      _pinToClasses.putIfAbsent(pin, () => []).add(className);
    }

    // Load class -> pin
    final classList = _prefs!.getStringList(_KEY_CLASS_MAP) ?? [];
    _classToPin.clear();
    for (int i = 0; i < classList.length; i += 2) {
      final className = classList[i];
      final pin = classList[i + 1];
      _classToPin[className] = pin;
    }
  }

  Future<void> _saveToPrefs() async {
    if (_prefs == null) return;

    // Save pin -> classes
    final pinList = <String>[];
    _pinToClasses.forEach((pin, classes) {
      for (final className in classes) {
        pinList.add(pin);
        pinList.add(className);
      }
    });
    await _prefs!.setStringList(_KEY_PIN_MAP, pinList);

    // Save class -> pin
    final classList = <String>[];
    _classToPin.forEach((className, pin) {
      classList.add(className);
      classList.add(pin);
    });
    await _prefs!.setStringList(_KEY_CLASS_MAP, classList);
  }

  // ✅ Tetap return void seperti versi lama
  Future<void> createClassWithPin(String className, String pin) async {
    await _ensureInitialized();

    if (className.isEmpty || pin.isEmpty) {
      throw ArgumentError('Nama kelas dan PIN tidak boleh kosong');
    }

    if (_classToPin.containsKey(className)) {
      throw StateError('Kelas "$className" sudah memiliki PIN');
    }

    // ✅ Izinkan PIN sama — tambahkan ke list
    _pinToClasses.putIfAbsent(pin, () => []).add(className);
    _classToPin[className] = pin;

    await _saveToPrefs();
  }

  Future<bool> verifyPinForClass(String className, String pin) async {
    await _ensureInitialized();
    return _classToPin[className] == pin;
  }

  // ✅ Tetap return String? seperti versi lama
  // Jika ada banyak kelas, return yang pertama (untuk kompatibilitas)
  Future<String?> getClassByPin(String pin) async {
    await _ensureInitialized();
    final classes = _pinToClasses[pin];
    return classes?.isNotEmpty == true ? classes!.first : null;
  }

  // ✅ Tambahkan method baru untuk ambil SEMUA kelas
  Future<List<String>?> getAllClassesByPin(String pin) async {
    await _ensureInitialized();
    return _pinToClasses[pin]?.toList();
  }

  Future<String?> getClassByPinForClass(String className) async {
    await _ensureInitialized();
    return _classToPin[className];
  }

  Future<bool> hasPinForClass(String className) async {
    await _ensureInitialized();
    return _classToPin.containsKey(className);
  }

  Future<void> resetAll() async {
    await _ensureInitialized();
    _pinToClasses.clear();
    _classToPin.clear();
    await _prefs!.remove(_KEY_PIN_MAP);
    await _prefs!.remove(_KEY_CLASS_MAP);
  }
}