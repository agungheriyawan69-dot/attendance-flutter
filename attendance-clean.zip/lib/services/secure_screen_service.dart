// lib/services/secure_screen_service.dart
import 'package:flutter/services.dart';

class SecureScreenService {
  static const _channel = MethodChannel('secure_screen');

  static Future<void> enable() async {
    await _channel.invokeMethod('setSecure', true);
  }

  static Future<void> disable() async {
    await _channel.invokeMethod('setSecure', false);
  }
}