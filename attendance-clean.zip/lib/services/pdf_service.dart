// lib/services/pdf_service.dart
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';

class PdfService {
  // ✅ TIDAK ADA DatabaseService di sini — sesuai prinsip single responsibility

  Future<File> generateAttendancePdfWithRange(
      String className,
      List<Map<String, dynamic>> data,
      DateTime startDate,
      DateTime endDate,
      ) async {
    final pdf = pw.Document();
    final now = DateTime.now();

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (context) => [
          pw.Center(
            child: pw.Column(
              children: [
                pw.Text(
                  'LAPORAN ABSENSI DIGITAL',
                  style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold),
                ),
                pw.SizedBox(height: 6),
                pw.Text(
                  className.toUpperCase(),
                  style: pw.TextStyle(fontSize: 16, color: PdfColors.blueGrey900),
                ),
                pw.SizedBox(height: 4),
                pw.Text(
                  'Periode: ${DateFormat('d MMM yyyy').format(startDate)} - ${DateFormat('d MMM yyyy').format(endDate)}',
                  style: pw.TextStyle(fontSize: 12, color: PdfColors.grey600),
                ),
                pw.SizedBox(height: 8),
                pw.Text(
                  'Dicetak: ${DateFormat('dd MMM yyyy, HH:mm').format(now)}',
                  style: pw.TextStyle(fontSize: 10, color: PdfColors.grey500),
                ),
              ],
            ),
          ),
          pw.SizedBox(height: 20),
          pw.Table.fromTextArray(
            headers: const ['No', 'Student ID', 'Nama', 'Tanggal', 'Waktu'],
            data: List.generate(data.length, (i) {
              final r = data[i];
              return [
                '${i + 1}',
                r['nim'] ?? '-',
                r['name'] ?? '-',
                r['date'] ?? '-',
                r['time'] ?? '-',
              ];
            }),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.teal800),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
            border: pw.TableBorder.all(width: 0.5),
            cellHeight: 24,
          ),
          pw.SizedBox(height: 24),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('Total: ${data.length} kehadiran', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              pw.Text('Kelas: $className', style: pw.TextStyle(fontSize: 10)),
            ],
          ),
        ],
      ),
    );

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/absensi_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }
}