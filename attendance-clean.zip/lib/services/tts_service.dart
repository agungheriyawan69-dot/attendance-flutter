// lib/services/tts_service.dart
import 'package:flutter_tts/flutter_tts.dart';

class TtsService {
  static final TtsService _instance = TtsService._();
  factory TtsService() => _instance;
  TtsService._();

  FlutterTts? _engine;
  bool _isSpeaking = false;

  Future<void> _ensureInit() async {
    if (_engine != null) return; // ✅ cukup ini — tidak perlu ?. atau null check berlebihan
    _engine = FlutterTts();
  }

  Future<void> speak(String text) async {
    await _ensureInit();
    if (_engine == null) return;

    // ✅ Deteksi bahasa yang didukung — tetap prioritaskan English
    List<String>? rawLanguages;
    try {
      rawLanguages = await _engine!.getLanguages;
    } catch (e) {
      print("TTS getLanguages failed: $e");
    }

    // ✅ Filter hanya string non-null
    final List<String> languages = rawLanguages?.whereType<String>().toList() ?? [];

    // ✅ Prioritas: en-US > en-GB > en > fallback
    String? targetLang;
    for (final lang in ['en-US', 'en-GB', 'en']) {
      if (languages.any((l) => l.toLowerCase() == lang.toLowerCase())) {
        targetLang = lang;
        break;
      }
    }

    // Fallback: cari yang mengandung 'en'
    if (targetLang == null) {
      targetLang = languages.firstWhere(
            (l) => l.toLowerCase().contains('en'),
        orElse: () => languages.isNotEmpty ? languages[0] : 'en-US',
      );
    }

    // ✅ Set language — ini yang jaga tetap English
    try {
      await _engine!.setLanguage(targetLang);
      await _engine!.setSpeechRate(0.3);
      await _engine!.setVolume(1.0);
    } catch (e) {
      print("TTS config failed for '$targetLang': $e");
    }

    // Hindari overlap
    if (_isSpeaking) {
      try { await _engine!.stop(); } catch (_) {}
    }
    _isSpeaking = true;

    try {
      print("📢 Speaking (lang: $targetLang): '$text'"); // tetap ada untuk debug
      await _engine!.speak(text);
    } catch (e) {
      print("TTS speak failed: $e");
    } finally {
      _isSpeaking = false;
    }
  }

  Future<void> stop() async {
    if (_engine == null) return;
    try { await _engine!.stop(); } catch (_) {}
    _isSpeaking = false;
  }

  Future<void> speakWelcome() async {
    await speak("Welcome to Attendance");
  }
}