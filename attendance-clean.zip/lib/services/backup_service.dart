// lib/services/backup_service.dart
import 'dart:convert';
import '../services/pin_service.dart';
import '../services/database_service.dart';

class BackupService {
  static Future<String> generateBackupQr(String className) async {
    // Ambil data terkini
    final pin = await PinService.instance.getClassByPinForClass(className);
    final students = await DatabaseService().getStudents(className);
    final sessions = await DatabaseService().getSessions(className);

    final data = {
      'v': '1.0',
      'className': className,
      'pin': pin,
      'students': students,
      'sessions': sessions,
    };

    final jsonStr = jsonEncode(data);
    final base64 = base64Encode(utf8.encode(jsonStr));
    return 'BACKUP:v1:$base64';
  }

  static Map<String, dynamic> parseBackupQr(String raw) {
    if (!raw.startsWith('BACKUP:v1:')) {
      throw 'Format QR tidak valid';
    }
    final base64 = raw.substring(9);
    final jsonStr = utf8.decode(base64Decode(base64));
    return jsonDecode(jsonStr);
  }

  static Future<void> restoreFromData(Map<String, dynamic> data) async {
    final className = data['className'] as String;
    final pin = data['pin'] as String?;

    // Simpan PIN
    if (pin != null) {
      await PinService.instance.createClassWithPin(className, pin);
    }

    // Simpan siswa
    final db = DatabaseService();
    for (final s in data['students'] ?? []) {
      await db.insertStudent(className, s['nim'], s['name']);
    }

    // Simpan sesi (opsional)
    for (final s in data['sessions'] ?? []) {
      await db.createSession(className, s['sessionId'], createdAt: DateTime.tryParse(s['createdAt']));
    }
  }
}