// lib/screens/role_selection.dart
import 'package:flutter/material.dart';
import 'package:attendance/screens/leader_pin_screen.dart';
import 'package:attendance/screens/student_screen.dart';
import 'package:attendance/screens/create_class_screen.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class RoleSelectionScreen extends StatefulWidget {
  const RoleSelectionScreen({super.key}); // ✅ hapus className & sessionId

  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _opacityAnimation;
  late Animation<double> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 900),
      vsync: this,
    );
    _opacityAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
    _slideAnimation = Tween<double>(begin: 30, end: 0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Interval(0.2, 1, curve: Curves.easeOutBack),
      ),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggleTheme() {
    context.read<ThemeProvider>().toggleTheme();
  }

  bool get _isDark => context.watch<ThemeProvider>().isDarkMode;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pilih Peran"),
        actions: [
          IconButton(
            icon: Icon(
              _isDark ? Icons.light_mode : Icons.dark_mode,
              color: _isDark ? Colors.amber : Colors.grey[700],
            ),
            onPressed: _toggleTheme,
            tooltip: _isDark ? 'Mode Terang' : 'Mode Gelap',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color(0xFFE94E77),
              const Color(0xFFF5A623),
              const Color(0xFF20B2AA),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) {
                    return Transform.translate(
                      offset: Offset(0, _slideAnimation.value),
                      child: Opacity(
                        opacity: _opacityAnimation.value,
                        child: ShaderMask(
                          shaderCallback: (rect) {
                            return const LinearGradient(
                              colors: [Colors.white, Colors.amber],
                              stops: [0.4, 1.0],
                            ).createShader(
                              Rect.fromLTRB(0, 0, rect.width, rect.height),
                            );
                          },
                          child: const Text(
                            'ATTENDANCE',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 48,
                              fontWeight: FontWeight.bold,
                              shadows: [
                                Shadow(offset: Offset(0, 2), blurRadius: 4, color: Colors.black38),
                                Shadow(offset: Offset(0, 6), blurRadius: 12, color: Colors.black26),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 8),
                AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) {
                    return Transform.translate(
                      offset: Offset(0, _slideAnimation.value * 0.7),
                      child: Opacity(
                        opacity: _opacityAnimation.value * 0.9,
                        child: const Text(
                          'Absensi Berbasis Digital',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.white70,
                            fontWeight: FontWeight.w500,
                            shadows: [
                              Shadow(offset: Offset(1, 2), blurRadius: 3, color: Colors.black45),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 30),
                _buildButton("Buat Kelas", () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const CreateClassScreen()),
                  );
                }),
                const SizedBox(height: 20),
                _buildButton("Masuk sebagai Leader", () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const LeaderPinScreen()),
                  );
                }),
                const SizedBox(height: 20),
                _buildButton("Masuk sebagai Student", () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const StudentScreen()),
                  );
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildButton(String label, VoidCallback onPressed) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFFE94E77),

        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        minimumSize: const Size(double.infinity, 50),
      ),
      onPressed: onPressed,
      child: Text(label, style: const TextStyle(fontSize: 16)),
    );
  }
}