// lib/screens/student_scan_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/database_service.dart';
import '../services/tts_service.dart';
import '../services/qr_service.dart';

class StudentScanScreen extends StatefulWidget {
  final String className;
  final String studentNim;
  final String studentName;

  const StudentScanScreen({
    super.key,
    required this.className,
    required this.studentNim,
    required this.studentName,
  });

  @override
  State<StudentScanScreen> createState() => _StudentScanScreenState();
}

class _StudentScanScreenState extends State<StudentScanScreen> {
  final _db = DatabaseService();
  bool _isScanning = true;
  String? _scanResult;
  bool _isProcessing = false;

  @override
  void initState() {
    super.initState();
    _setSecure(true);
  }

  @override
  void dispose() {
    _setSecure(false);
    super.dispose();
  }

  Future<void> _setSecure(bool secure) async {
    try {
      const channel = MethodChannel('secure_screen');
      await channel.invokeMethod('setSecure', secure);
    } catch (_) {}
  }

  Future<void> _processQR(String rawValue) async {
    if (_isProcessing) return;
    setState(() => _isProcessing = true);

    await TtsService().stop();
    await TtsService().speak("Scanning");

    final qrData = QRService.parseAttendanceQR(rawValue);
    if (qrData == null) {
      await _showResultAndSpeak("Scan failed", "QR tidak valid atau kadaluarsa", success: false);
      return;
    }

    final qrClass = qrData['class_id'] as String?;
    final qrNim = qrData['nim'] as String?;
    final qrSession = qrData['session_id'] as String?;

    if (qrClass == null || qrNim == null || qrSession == null) {
      await _showResultAndSpeak("Scan failed", "Data QR tidak lengkap", success: false);
      return;
    }

    if (qrClass != widget.className) {
      await _showResultAndSpeak("Scan failed", "QR bukan untuk kelas ini", success: false);
      return;
    }

    if (qrNim != widget.studentNim) {
      await _showResultAndSpeak("Scan failed", "QR bukan untuk Anda", success: false);
      return;
    }

    final attendanceRecords = await _db.getAttendance(widget.className, qrSession);
    if (attendanceRecords.any((a) => a['nim'] == widget.studentNim)) {
      await _showResultAndSpeak("Scan failed", "Anda sudah absen di sesi ini", success: false);
      return;
    }

    try {
      await _db.insertAttendance(
        className: widget.className,
        sessionId: qrSession,
        nim: widget.studentNim,
        name: widget.studentName,
      );

      final now = DateTime.now();
      final date = '${now.day.toString().padLeft(2, '0')}-${now.month.toString().padLeft(2, '0')}-${now.year}';
      final time = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

      await _showResultAndSpeak(
        "Scan successful",
        '✅ Absen berhasil!\n${widget.studentName}\n$qrSession\n${date} ${time}',
        success: true,
      );

      await Future.delayed(const Duration(seconds: 2));
      if (mounted) Navigator.pop(context);
    } catch (e) {
      await _showResultAndSpeak("Scan failed", "Gagal menyimpan", success: false);
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  Future<void> _showResultAndSpeak(String ttsText, String uiText, {required bool success}) async {
    await TtsService().speak(ttsText);
    if (mounted) {
      setState(() => _scanResult = uiText);
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) setState(() => _scanResult = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text('Absen • ${widget.className}'),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          _isScanning
              ? MobileScanner(
            onDetect: (capture) {
              if (_isProcessing) return;
              for (final barcode in capture.barcodes) {
                final rawValue = barcode.rawValue;
                if (rawValue != null) {
                  _processQR(rawValue);
                }
              }
            },
          )
              : const Center(child: Text('Kamera dihentikan')),

          Positioned.fill(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  color: Colors.black54,
                  child: Column(
                    children: [
                      const Text(
                        "Arahkan kamera ke QR absen",
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "⚠️ Layar ini tidak bisa di-screenshot untuk keamanan",
                        style: TextStyle(color: Colors.orange, fontSize: 12),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          if (_scanResult != null)
            Positioned(
              top: 60,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _scanResult!.contains('✅') ? Colors.green.withOpacity(0.9) : Colors.red.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _scanResult!,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),

          if (_isProcessing)
            const Positioned(
              top: 20,
              left: 0,
              right: 0,
              child: Center(child: CircularProgressIndicator(color: Colors.white)),
            ),
        ],
      ),
    );
  }
}