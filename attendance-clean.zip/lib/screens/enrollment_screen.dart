// lib/screens/enrollment_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // ✅ untuk inputFormatters
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/database_service.dart';
import '../utils/string_utils.dart';
import 'edit_student.dart';

class EnrollmentScreen extends StatefulWidget {
  final String className;
  const EnrollmentScreen({super.key, required this.className});

  @override
  State<EnrollmentScreen> createState() => _EnrollmentScreenState();
}

class _EnrollmentScreenState extends State<EnrollmentScreen> {
  final _db = DatabaseService();
  final _nimController = TextEditingController();
  final _nameController = TextEditingController();
  bool _isSubmitting = false;

  // ✅ Fungsi normalisasi nama
  String normalizeName(String raw) {
    return raw.trim().toLowerCase().split(' ').map((word) {
      if (word.isEmpty) return '';
      return '${word[0].toUpperCase()}${word.substring(1)}';
    }).join(' ');
  }

  bool get _isNimValid {
    final nim = _nimController.text.trim();
    return nim.length >= 8 &&
        nim.length <= 15 &&
        RegExp(r'^[A-Z0-9]+$').hasMatch(nim);
  }

  bool get _isFormValid => _isNimValid && _nameController.text.trim().isNotEmpty;

  Future<void> _addStudent() async {
    if (!_isFormValid || _isSubmitting) return;
    setState(() => _isSubmitting = true);
    final nim = _nimController.text.trim(); // sudah uppercase karena input formatter
    final name = normalizeName(_nameController.text); // ✅ otomatis jadi "Agung Heriyawan"
    final cleanClassName = normalizeClassName(widget.className);
    try {
      await _db.insertStudent(nim, name, cleanClassName);
      _nimController.clear();
      _nameController.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("✅ Student ID berhasil didaftarkan"),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        final msg = e.toString().contains('NIM sudah terdaftar')
            ? "Student ID sudah terdaftar"
            : "Gagal mendaftarkan Student ID";
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ $msg")),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;
    return Scaffold(
      appBar: AppBar(
        title: Text("Enroll Student • ${widget.className}"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isDark
                ? const [Color(0xFF121212), Color(0xFF0A0A0A)]
                : const [Color(0xFFF5F7FA), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Daftarkan Student ID',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: isDark ? Colors.white : const Color(0xFF333333),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Untuk ${widget.className}',
                      style: TextStyle(
                        fontSize: 14,
                        color: isDark ? Colors.white70 : const Color(0xFF666666),
                      ),
                    ),
                    const SizedBox(height: 32),
                    _buildTextField(
                      controller: _nimController,
                      label: "Student ID",
                      hint: "Contoh: A221043",
                      isDark: isDark,
                      capitalization: TextCapitalization.characters,
                      errorText:
                      _nimController.text.isNotEmpty && !_isNimValid
                          ? "8–15 karakter, huruf kapital & angka"
                          : null,
                      // ✅ BATAS INPUT DI SINI
                      inputFormatters: [
                        LengthLimitingTextInputFormatter(15),
                        FilteringTextInputFormatter.allow(RegExp(r'[A-Z0-9]')),
                      ],
                    ),
                    const SizedBox(height: 20),
                    _buildTextField(
                      controller: _nameController,
                      label: "Nama Lengkap",
                      hint: "Contoh: Budi Santoso",
                      isDark: isDark,
                      capitalization: TextCapitalization.none, // biar user bebas
                      errorText: _nameController.text.isNotEmpty &&
                          _nameController.text.trim().length < 2
                          ? "Minimal 2 karakter"
                          : null,
                      // ✅ Hanya huruf & spasi
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z\s]')),
                      ],
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: _isFormValid && !_isSubmitting
                            ? _addStudent
                            : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFE94E77),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                        child: _isSubmitting
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Text("✅ Tambah Student ID",
                            style: TextStyle(fontSize: 16)),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                EditStudentScreen(className: widget.className),
                          ),
                        );
                      },
                      icon: const Icon(Icons.edit, color: Color(0xFFE94E77)),
                      label: const Text(
                        "✏️ Kelola Daftar Student ID",
                        style: TextStyle(
                            color: Color(0xFFE94E77), fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required bool isDark,
    required TextCapitalization capitalization,
    String? errorText,
    List<TextInputFormatter>? inputFormatters, // ✅ tambahkan ini
  }) {
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: isDark ? Colors.black45 : Colors.black12,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        inputFormatters: inputFormatters, // ✅ pasang di sini
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(
            color: Color(0xFFE94E77),
            fontWeight: FontWeight.bold,
          ),
          hintText: hint,
          hintStyle:
          TextStyle(color: isDark ? Colors.grey : Colors.grey[600]),
          errorText: errorText,
          errorStyle: const TextStyle(height: 0.5),
          contentPadding:
          const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
          border: InputBorder.none,
          prefixIcon: const Icon(Icons.person, color: Color(0xFFE94E77)),
        ),
        autocorrect: false,
        textCapitalization: capitalization,
        onChanged: (_) => setState(() {}),
      ),
    );
  }
}