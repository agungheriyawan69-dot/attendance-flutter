// lib/screens/export_pdf_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/theme_provider.dart';
import '../services/database_service.dart';
import '../services/pdf_service.dart';
import 'package:share_plus/share_plus.dart';

class ExportPdfScreen extends StatefulWidget {
  final String className;
  const ExportPdfScreen({super.key, required this.className});

  @override
  State<ExportPdfScreen> createState() => _ExportPdfScreenState();
}

class _ExportPdfScreenState extends State<ExportPdfScreen> {
  final _db = DatabaseService();
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 6));
  DateTime _endDate = DateTime.now();
  int _studentCount = 0;
  int _sessionCount = 0;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _updateSummary();
  }

  Future<void> _updateSummary() async {
    try {
      final allData = await _db.getAttendanceRecords(widget.className);
      final filtered = _filterData(allData);

      final students = filtered.map((r) => r['nim']).toSet().length;
      final sessions = filtered.map((r) => r['sessionId']).toSet().length;

      if (mounted) {
        setState(() {
          _studentCount = students;
          _sessionCount = sessions;
        });
      }
    } catch (_) {}
  }

  List<Map<String, dynamic>> _filterData(List<Map<String, dynamic>> data) {
    return data.where((r) {
      final dateStr = r['date'] as String?;
      if (dateStr == null || dateStr.isEmpty) return false;
      final parts = dateStr.split('-'); // DD-MM-YYYY
      if (parts.length != 3) return false;
      final d = DateTime.tryParse('${parts[2]}-${parts[1]}-${parts[0]}');
      return d != null &&
          (d.isAfter(_startDate) || d.isAtSameMomentAs(_startDate)) &&
          (d.isBefore(_endDate.add(const Duration(days: 1))) || d.isAtSameMomentAs(_endDate));
    }).toList();
  }

  Future<void> _selectStartDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _startDate) {
      setState(() => _startDate = picked);
      _updateSummary();
    }
  }

  Future<void> _selectEndDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _endDate,
      firstDate: _startDate,
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _endDate) {
      setState(() => _endDate = picked);
      _updateSummary();
    }
  }

  Future<void> _exportPdf() async {
    if (_studentCount == 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Tidak ada data")));
      return;
    }

    setState(() => _loading = true);

    try {
      final allData = await _db.getAttendanceRecords(widget.className);
      final filtered = _filterData(allData);

      final pdf = await PdfService().generateAttendancePdfWithRange(
        widget.className,
        filtered,
        _startDate,
        _endDate,
      );

      await Share.shareXFiles(
        [XFile(pdf.path)],
        subject: 'Absensi ${widget.className}',
        text: 'Periode: ${DateFormat('d MMM yyyy').format(_startDate)} - ${DateFormat('d MMM yyyy').format(_endDate)}\n'
            'Siswa: $_studentCount • Sesi: $_sessionCount',
      );

      // ✅ Feedback sukses
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("✅ PDF berhasil dibagikan"),
            backgroundColor: Colors.green,
          ),
        );
      }

    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ Gagal: ${e.toString().split('\n').first}")),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text("Export PDF • ${widget.className}"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isDark
                ? const [Color(0xFF1E1E1E), Color(0xFF0A0A0A)]
                : const [Color(0xFFF5F7FA), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ✅ Header jelas
                  Text(
                    "Buat Laporan Absensi",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : const Color(0xFF333333),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Pilih rentang tanggal, lalu generate PDF",
                    style: TextStyle(
                      fontSize: 14,
                      color: isDark ? Colors.white70 : const Color(0xFF666666),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // ✅ Pemilihan tanggal
                  _buildDateCard(
                    context,
                    title: "Dari Tanggal",
                    date: _startDate,
                    onTap: _selectStartDate,
                    icon: Icons.calendar_today_outlined,
                    color: Colors.blue,
                  ),
                  const SizedBox(height: 16),
                  _buildDateCard(
                    context,
                    title: "Sampai Tanggal",
                    date: _endDate,
                    onTap: _selectEndDate,
                    icon: Icons.calendar_today,
                    color: Colors.green,
                  ),
                  const SizedBox(height: 24),

                  // ✅ Ringkasan data (live update)
                  Card(
                    color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Ringkasan Data",
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          const SizedBox(height: 12),
                          _buildSummaryRow("👥 Siswa Terdaftar", '$_studentCount'),
                          const SizedBox(height: 8),
                          _buildSummaryRow("📅 Sesi Absen", '$_sessionCount'),
                          const SizedBox(height: 8),
                          _buildSummaryRow(
                            "📆 Periode",
                            "${DateFormat('d MMM yyyy').format(_startDate)} - ${DateFormat('d MMM yyyy').format(_endDate)}",
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // ✅ Tombol utama
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton.icon(
                      onPressed: _studentCount > 0 && !_loading ? _exportPdf : null,
                      icon: _loading
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Icon(Icons.picture_as_pdf, size: 24),
                      label: Text(
                        _loading ? "Sedang membuat..." : "📤 Bagikan PDF",
                        style: const TextStyle(fontSize: 16),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE94E77),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),

                  // ✅ Petunjuk
                  const SizedBox(height: 20),
                  Card(
                    color: isDark ? Colors.blueGrey.withOpacity(0.2) : Colors.blue.withOpacity(0.05),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("📌 Cara Penggunaan:", style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          const Text("1. Pilih rentang tanggal"),
                          const Text("2. Lihat ringkasan data di atas"),
                          const Text("3. Klik 'Bagikan PDF'"),
                          const Text("4. Pilih aplikasi (WhatsApp/Email)"),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDateCard(BuildContext context, {
    required String title,
    required DateTime date,
    required VoidCallback onTap,
    required IconData icon,
    required Color color,
  }) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Card(
      color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(
                      DateFormat('EEEE, d MMMM yyyy', 'id').format(date),
                      style: TextStyle(
                        color: isDark ? Colors.white70 : Colors.grey[600],
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, size: 16, color: isDark ? Colors.white70 : Colors.grey[600]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
      ],
    );
  }
}