// lib/screens/restore_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../providers/theme_provider.dart';
import '../services/backup_service.dart';
import '../providers/app_state.dart';
import 'leader_dashboard.dart';

class RestoreScreen extends StatefulWidget {
  const RestoreScreen({super.key}); // ✅ TANPA className

  @override
  State<RestoreScreen> createState() => _RestoreScreenState();
}

class _RestoreScreenState extends State<RestoreScreen> {
  bool _isScanning = true;
  String? _message;

  Future<void> _processQr(String raw) async {
    if (!raw.startsWith('BACKUP:v1:')) {
      setState(() => _message = '❌ QR tidak valid. Pastikan ini QR Backup.');
      return;
    }

    try {
      final data = BackupService.parseBackupQr(raw);
      final className = data['className'] as String;
      final pin = data['pin'] as String;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => RestorePinScreen(
            className: className, // ✅ className dari QR, bukan dari widget
            pin: pin,
            backupData: data,
          ),
        ),
      );
    } catch (e) {
      setState(() => _message = '❌ Gagal memproses QR: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Restore dari QR"), // ✅ tanpa className
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: Column(
        children: [
          Expanded(
            child: _isScanning
                ? MobileScanner(
              onDetect: (capture) {
                for (final barcode in capture.barcodes) {
                  final raw = barcode.rawValue;
                  if (raw != null) {
                    _processQr(raw);
                  }
                }
              },
            )
                : const Center(child: Text('Scan selesai')),
          ),
          if (_message != null)
            Container(
              color: Colors.red.withOpacity(0.1),
              padding: const EdgeInsets.all(16),
              child: Text(_message!, style: const TextStyle(color: Colors.red)),
            ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              "Arahkan kamera ke QR Backup dari device utama.",
              textAlign: TextAlign.center,
              style: TextStyle(color: isDark ? Colors.white70 : Colors.grey[600]),
            ),
          ),
        ],
      ),
    );
  }
}

// RestorePinScreen tetap sama — butuh className, pin, backupData
class RestorePinScreen extends StatefulWidget {
  final String className;
  final String pin;
  final Map<String, dynamic> backupData;

  const RestorePinScreen({
    super.key,
    required this.className,
    required this.pin,
    required this.backupData,
  });

  @override
  State<RestorePinScreen> createState() => _RestorePinScreenState();
}

class _RestorePinScreenState extends State<RestorePinScreen> {
  final _pinController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  Future<void> _verifyAndRestore() async {
    if (!_formKey.currentState!.validate()) return;

    final inputPin = _pinController.text.trim();
    if (inputPin != widget.pin) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("PIN salah")),
      );
      return;
    }

    await BackupService.restoreFromData(widget.backupData);

    final appState = context.read<AppState>();
    await appState.setCurrentClass(widget.className);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => LeaderDashboard(className: widget.className), // ✅ hanya className
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Verifikasi PIN"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Masukkan PIN kelas untuk verifikasi",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            Form(
              key: _formKey,
              child: TextFormField(
                controller: _pinController,
                decoration: const InputDecoration(
                  labelText: "PIN",
                  hintText: "Contoh: 123456",
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) return "Wajib diisi";
                  if (value.length < 6) return "Minimal 6 digit";
                  return null;
                },
                onFieldSubmitted: (_) => _verifyAndRestore(),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _verifyAndRestore,
                child: const Text("Restore & Masuk"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}