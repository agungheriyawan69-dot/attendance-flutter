import 'package:flutter/material.dart';
import 'package:attendance/services/pin_service.dart';

class CreateClassScreen extends StatefulWidget {
  const CreateClassScreen({super.key});

  @override
  State<CreateClassScreen> createState() => _CreateClassScreenState();
}

class _CreateClassScreenState extends State<CreateClassScreen> {
  final _classNameController = TextEditingController();
  final _leaderNimController = TextEditingController();
  final _pinController = TextEditingController();

  Future<void> _createClass() async {
    final className = _classNameController.text.trim();
    final leaderNim = _leaderNimController.text.trim();
    final pin = _pinController.text.trim();

    if (className.isEmpty) {
      _showMessage('Nama kelas wajib diisi');
      return;
    }

    if (leaderNim.isEmpty) {
      _showMessage('NIM Ketua Kelas wajib diisi');
      return;
    }

    if (pin.length < 4 || pin.length > 6 || !RegExp(r'^\d+$').hasMatch(pin)) {
      _showMessage('PIN harus 4–6 digit angka');
      return;
    }

    try {
      await PinService.instance.createClassWithPin(className, pin);

      // ✅ Simpan NIM leader ke database — kamu bisa tambahkan di sini nanti
      // await DatabaseService().registerLeader(className, leaderNim, pin);

      _showMessage('✅ Kelas "$className" berhasil dibuat!\nNIM Leader: $leaderNim\nPIN: $pin');
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) Navigator.pop(context);
      });
    } catch (e) {
      _showMessage('❌ Gagal: $e');
    }
  }

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: msg.startsWith('✅') ? Colors.green : Colors.red,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // ✅ Icon & judul
                const Icon(
                  Icons.class_,
                  size: 64,
                  color: Color(0xFFE94E77),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Buat Kelas Baru',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF333333),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Daftarkan kelas beserta ketua dan PIN akses',
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF666666),
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 40),

                // ✅ Input Nama Kelas
                _buildInputField(
                  controller: _classNameController,
                  label: 'Nama Kelas',
                  hint: 'Contoh: TLPE 019',
                  icon: Icons.school,
                ),
                const SizedBox(height: 20),

                // ✅ Input NIM Ketua
                _buildInputField(
                  controller: _leaderNimController,
                  label: 'NIM Ketua Kelas',
                  hint: 'Contoh: 2310123456',
                  icon: Icons.person,
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 20),

                // ✅ Input PIN
                _buildInputField(
                  controller: _pinController,
                  label: 'PIN Akses (4–6 digit)',
                  hint: 'Contoh: 1234',
                  icon: Icons.lock,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                ),
                const SizedBox(height: 40),

                // ✅ Tombol Pink — jelas & presisi
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: _createClass,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE94E77),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      elevation: 0,
                    ),
                    child: const Text(
                      'BUAT KELAS',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    bool obscureText = false,
    TextInputType? keyboardType,
    int? maxLength,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(
            color: Color(0xFFE94E77),
            fontWeight: FontWeight.bold,
          ),
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.grey),
          contentPadding: const EdgeInsets.symmetric(
            vertical: 16,
            horizontal: 20,
          ),
          border: InputBorder.none,
          prefixIcon: Icon(icon, color: const Color(0xFFE94E77)),
          suffixIcon: controller.text.isNotEmpty
              ? IconButton(
            icon: const Icon(Icons.clear, size: 18),
            onPressed: () => controller.clear(),
            color: Colors.grey,
          )
              : null,
        ),
        obscureText: obscureText,
        keyboardType: keyboardType,
        maxLength: maxLength,
      ),
    );
  }
}