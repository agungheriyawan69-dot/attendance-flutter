// lib/screens/edit_student.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/database_service.dart';
import '../utils/string_utils.dart';

class EditStudentScreen extends StatefulWidget {
  final String className;
  const EditStudentScreen({super.key, required this.className});

  @override
  State<EditStudentScreen> createState() => _EditStudentScreenState();
}

class _EditStudentScreenState extends State<EditStudentScreen> {
  final _db = DatabaseService();
  late Future<List<Map<String, dynamic>>> _studentsFuture;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final cleanClassName = normalizeClassName(widget.className);
    _studentsFuture = _db.getStudents(cleanClassName);
  }

  // ✅ Fungsi normalisasi nama (sama seperti di enrollment)
  String normalizeName(String raw) {
    return raw.trim().toLowerCase().split(' ').map((word) {
      if (word.isEmpty) return '';
      return '${word[0].toUpperCase()}${word.substring(1)}';
    }).join(' ');
  }

  Future<void> _deleteStudent(String nim) async {
    final cleanClassName = normalizeClassName(widget.className);
    await _db.deleteStudent(cleanClassName, nim);
    if (!mounted) return;
    setState(() {
      final cleanClassName = normalizeClassName(widget.className);
      _studentsFuture = _db.getStudents(cleanClassName);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("✅ Student $nim dihapus")),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;
    return Scaffold(
      appBar: AppBar(
        title: Text("Kelola Student • ${widget.className}"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isDark
                ? const [Color(0xFF121212), Color(0xFF0A0A0A)]
                : const [Color(0xFFF5F7FA), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Cari Student ID atau Nama',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: isDark ? Colors.grey[700]! : Colors.grey,
                      ),
                    ),
                    filled: true,
                    fillColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                  ),
                  style: TextStyle(color: isDark ? Colors.white : Colors.black),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              Expanded(
                child: FutureBuilder<List<Map<String, dynamic>>>(
                  future: _studentsFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    if (snapshot.hasError) {
                      return Center(
                        child: Text("Error: ${snapshot.error}"),
                      );
                    }
                    final students = snapshot.data ?? [];
                    final query = _searchController.text.toLowerCase().trim();
                    final filtered = students.where((student) {
                      final nim = student['nim'].toString().toLowerCase();
                      final name = student['name'].toString().toLowerCase();
                      return nim.contains(query) || name.contains(query);
                    }).toList();

                    if (filtered.isEmpty) {
                      return const Center(
                        child: Text("Tidak ada data student"),
                      );
                    }

                    return ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        final student = filtered[index];
                        return _buildStudentCard(student, isDark);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStudentCard(Map<String, dynamic> student, bool isDark) {
    final nim = student['nim'] as String;
    final name = student['name'] as String;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
      elevation: 2,
      child: ListTile(
        title: Text(
          name,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: isDark ? Colors.white : Colors.black,
          ),
        ),
        subtitle: Text(
          "ID: $nim",
          style: TextStyle(
            color: isDark ? Colors.grey[400] : Colors.grey[600],
          ),
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete, color: Colors.red),
          onPressed: () => _deleteStudent(nim),
        ),
        // Opsional: tambahkan edit jika mau
      ),
    );
  }
}