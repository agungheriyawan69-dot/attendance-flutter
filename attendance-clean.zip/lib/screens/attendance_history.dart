// lib/screens/attendance_history_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/database_service.dart';
import '../services/pdf_service.dart';
import 'package:share_plus/share_plus.dart';

class AttendanceHistoryScreen extends StatefulWidget {
  final String className;
  const AttendanceHistoryScreen({super.key, required this.className});

  @override
  State<AttendanceHistoryScreen> createState() => _AttendanceHistoryScreenState();
}

class _AttendanceHistoryScreenState extends State<AttendanceHistoryScreen> {
  final DatabaseService _db = DatabaseService();
  List<Map<String, dynamic>> _records = [];
  List<Map<String, dynamic>> _filteredRecords = [];
  bool _loading = true;
  String _searchQuery = '';
  String _selectedStudent = 'Semua Siswa';
  List<String> _students = ['Semua Siswa'];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      // Bersihkan data lama
      await _db.cleanOldAttendance(widget.className, days: 30);

      // Ambil data
      final raw = await _db.getAttendanceRecords(widget.className);

      // Ambil daftar unik siswa
      final studentSet = <String>{'Semua Siswa'};
      for (final r in raw) {
        studentSet.add('${r['name']} (${r['nim']})');
      }
      final students = studentSet.toList()..sort();

      if (mounted) {
        setState(() {
          _records = raw;
          _filteredRecords = raw;
          _students = students;
          _loading = false;
        });
        _applyFilters();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal: $e')));
      }
    }
  }

  void _applyFilters() {
    List<Map<String, dynamic>> filtered = _records;

    // Filter berdasarkan pencarian
    if (_searchQuery.isNotEmpty) {
      final query = _searchQuery.toLowerCase();
      filtered = filtered.where((r) =>
      r['name'].toString().toLowerCase().contains(query) ||
          r['nim'].toString().toLowerCase().contains(query) ||
          r['sessionId'].toString().toLowerCase().contains(query)
      ).toList();
    }

    // Filter berdasarkan siswa
    if (_selectedStudent != 'Semua Siswa') {
      filtered = filtered.where((r) => '${r['name']} (${r['nim']})' == _selectedStudent).toList();
    }

    setState(() => _filteredRecords = filtered);
  }

  Future<void> _exportFiltered() async {
    if (_filteredRecords.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Tidak ada data")));
      return;
    }

    try {
      final pdf = await PdfService().generateAttendancePdfWithRange(
        widget.className,
        _filteredRecords,
        DateTime.now().subtract(const Duration(days: 365)),
        DateTime.now(),
      );

      await Share.shareXFiles(
        [XFile(pdf.path)],
        subject: 'Absensi ${widget.className}',
        text: 'Data terfilter: ${_filteredRecords.length} record',
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("✅ PDF berhasil dibagikan"), backgroundColor: Colors.green),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("❌ Gagal: $e")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text("Riwayat Siswa • ${widget.className}"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
        actions: [
          if (_filteredRecords.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.picture_as_pdf),
              onPressed: _exportFiltered,
              tooltip: "Export PDF",
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _records.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: isDark ? Colors.grey.withOpacity(0.1) : Colors.grey[100],
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.person_search, size: 64, color: isDark ? Colors.grey : Colors.grey[600]),
            ),
            Text(
              "Absensi akan muncul setelah mahasiswa\n"
                  "berhasil scan QR dari sesi yang aktif.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: isDark ? Colors.white70 : Colors.grey[600]),
            ),
            const SizedBox(height: 16),
            Text(
              "Belum ada data absensi",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : Colors.grey[700],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Mulai sesi absen untuk melihat riwayat",
              style: TextStyle(
                fontSize: 14,
                color: isDark ? Colors.white70 : Colors.grey[500],
              ),
            ),
          ],
        ),
      )
          : Column(
        children: [
          // ✅ Filter & search
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Search
                Container(
                  decoration: BoxDecoration(
                    color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: isDark ? Colors.black45 : Colors.black12,
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "Cari nama, NIM, atau sesi...",
                      prefixIcon: const Icon(Icons.search, color: Color(0xFFE94E77)),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                    ),
                    onChanged: (value) {
                      setState(() => _searchQuery = value);
                      _applyFilters();
                    },
                  ),
                ),
                const SizedBox(height: 12),

                // Dropdown siswa
                Container(
                  decoration: BoxDecoration(
                    color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: isDark ? Colors.black45 : Colors.black12,
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _selectedStudent,
                      items: _students.map((student) {
                        return DropdownMenuItem(
                          value: student,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                            child: Text(
                              student,
                              style: TextStyle(
                                color: isDark ? Colors.white : Colors.black,
                                fontWeight: student == _selectedStudent ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setState(() => _selectedStudent = value);
                          _applyFilters();
                        }
                      },
                      borderRadius: BorderRadius.circular(12),
                      dropdownColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                      icon: Icon(Icons.arrow_drop_down, color: const Color(0xFFE94E77)),
                      isExpanded: true,
                      style: TextStyle(color: isDark ? Colors.white : Colors.black),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ✅ Ringkasan
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Card(
              color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Ditemukan",
                      style: TextStyle(color: isDark ? Colors.white70 : Colors.grey[600]),
                    ),
                    Text(
                      "${_filteredRecords.length} dari ${_records.length}",
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),

          // ✅ Daftar absensi
          Expanded(
            child: _filteredRecords.isEmpty
                ? Center(
              child: Text(
                "Tidak ada data yang sesuai",
                style: TextStyle(color: isDark ? Colors.white70 : Colors.grey[600]),
              ),
            )
                : ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: _filteredRecords.length,
              itemBuilder: (context, index) {
                final r = _filteredRecords[index];
                return Card(
                  color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16),
                    leading: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.check, color: Colors.green, size: 20),
                    ),
                    title: Text(
                      r['name'],
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'NIM: ${r['nim']}',
                          style: TextStyle(color: isDark ? Colors.white70 : Colors.grey[600]),
                        ),
                        Text(
                          'Sesi: ${r['sessionId']}',
                          style: TextStyle(color: isDark ? Colors.white70 : Colors.grey[600]),
                        ),
                        Text(
                          'Tanggal: ${r['date']} • ${r['time']}',
                          style: TextStyle(color: isDark ? Colors.white70 : Colors.grey[600]),
                        ),
                      ],
                    ),
                    trailing: Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}