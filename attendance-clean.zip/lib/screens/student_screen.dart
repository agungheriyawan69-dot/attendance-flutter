// lib/screens/student_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/database_service.dart';
import '../services/tts_service.dart';
import 'student_scan_screen.dart';

class StudentScreen extends StatefulWidget {
  const StudentScreen({super.key});

  @override
  State<StudentScreen> createState() => _StudentScreenState();
}

class _StudentScreenState extends State<StudentScreen> {
  final _db = DatabaseService();
  final _classNameController = TextEditingController();
  final _nimController = TextEditingController();
  final _nameController = TextEditingController();
  bool _isSubmitting = false;

  bool get _isNimValid {
    final nim = _nimController.text.trim();
    return nim.length >= 8 &&
        nim.length <= 15 &&
        RegExp(r'^[A-Z0-9]+$').hasMatch(nim);
  }

  bool get _isFormValid => _isNimValid &&
      _classNameController.text.trim().isNotEmpty &&
      _nameController.text.trim().length >= 2;

  Future<void> _speak(String text) async {
    await TtsService().speak(text);
  }

  Future<void> _validateAndProceed() async {
    if (!_isFormValid || _isSubmitting) return;

    setState(() => _isSubmitting = true);

    final className = _classNameController.text.trim();
    final nim = _nimController.text.trim().toUpperCase();
    final name = _nameController.text.trim();

    if (!_isNimValid) {
      await _speak("Student ID invalid. Please enter 8 to 15 uppercase letters or digits.");
      if (mounted) setState(() => _isSubmitting = false);
      return;
    }

    try {
      final students = await _db.getStudents(className);
      final isEnrolled = students.any((s) => s['nim'] == nim);
      if (!isEnrolled) {
        await _speak("Student ID not enrolled. Please contact your leader.");
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("⚠️ Student ID belum terdaftar")),
          );
        }
        return;
      }

      await _speak("Student ID accepted. Proceed to QR scan.");

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => StudentScanScreen(
              className: className,
              studentNim: nim,
              studentName: name,
              // ✅ HAPUS sessionId — tidak diperlukan lagi
            ),
          ),
        );
      }

    } catch (e) {
      await _speak("Validation failed. Please try again.");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ Gagal: ${e.toString().split('\n').first}")),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Absensi Pelajar"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isDark
                ? const [Color(0xFF121212), Color(0xFF0A0A0A)]
                : const [Color(0xFFF5F7FA), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Verifikasi Identitas',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: isDark ? Colors.white : const Color(0xFF333333),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Sebelum scan QR absen',
                      style: TextStyle(
                        fontSize: 14,
                        color: isDark ? Colors.white70 : const Color(0xFF666666),
                      ),
                    ),
                    const SizedBox(height: 32),

                    _buildTextField(
                      controller: _classNameController,
                      label: "Nama Kelas",
                      hint: "Contoh: VI A / TLPE 019",
                      isDark: isDark,
                      errorText: _classNameController.text.isEmpty ? "Wajib diisi" : null,
                    ),
                    const SizedBox(height: 20),

                    _buildTextField(
                      controller: _nimController,
                      label: "Student ID",
                      hint: "Contoh: A221043",
                      isDark: isDark,
                      errorText: _nimController.text.isNotEmpty && !_isNimValid
                          ? "8–15 karakter, huruf kapital & angka"
                          : null,
                      textCapitalization: TextCapitalization.characters,
                      // ✅ Sekarang berfungsi — karena sudah import services.dart
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'[A-Z0-9]')),
                        LengthLimitingTextInputFormatter(15),
                      ],
                    ),
                    const SizedBox(height: 20),

                    _buildTextField(
                      controller: _nameController,
                      label: "Nama Lengkap",
                      hint: "Contoh: Budi Santoso",
                      isDark: isDark,
                      errorText: _nameController.text.isNotEmpty &&
                          _nameController.text.trim().length < 2
                          ? "Minimal 2 karakter"
                          : null,
                    ),
                    const SizedBox(height: 32),

                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: _isFormValid && !_isSubmitting ? _validateAndProceed : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFE94E77),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                        child: _isSubmitting
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Text("✅ Lanjut ke Scan QR", style: TextStyle(fontSize: 16)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required bool isDark,
    String? errorText,
    TextCapitalization textCapitalization = TextCapitalization.none,
    List<TextInputFormatter>? inputFormatters,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: isDark ? Colors.black45 : Colors.black12,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(
            color: Color(0xFFE94E77),
            fontWeight: FontWeight.bold,
          ),
          hintText: hint,
          hintStyle: TextStyle(color: isDark ? Colors.grey : Colors.grey[600]),
          errorText: errorText,
          errorStyle: const TextStyle(height: 0.5),
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
          border: InputBorder.none,
          prefixIcon: const Icon(Icons.person, color: Color(0xFFE94E77)),
        ),
        textCapitalization: textCapitalization,
        inputFormatters: inputFormatters,
        autocorrect: false,
        onChanged: (_) => setState(() {}),
      ),
    );
  }
}