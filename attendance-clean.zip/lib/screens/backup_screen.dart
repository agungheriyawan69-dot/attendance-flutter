// lib/screens/backup_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../providers/theme_provider.dart';
import '../services/backup_service.dart';
import 'restore_screen.dart'; // ✅ pastikan file ada

class BackupScreen extends StatefulWidget {
  final String className;
  const BackupScreen({super.key, required this.className});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  String? _backupQr;
  bool _isGenerating = false;

  Future<void> _generateBackup() async {
    if (_isGenerating) return;
    setState(() => _isGenerating = true);
    try {
      final qr = await BackupService.generateBackupQr(widget.className);
      if (mounted) setState(() => _backupQr = qr);
    } finally {
      if (mounted) setState(() => _isGenerating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text("Backup • ${widget.className}"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "📤 Generate QR Backup",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "QR ini berisi data kelas (nama, PIN, daftar siswa). "
                            "Simpan dengan aman — butuh PIN untuk restore.",
                        style: TextStyle(color: Colors.grey),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _generateBackup,
                          icon: const Icon(Icons.qr_code),
                          label: _isGenerating
                              ? const CircularProgressIndicator(color: Colors.white)
                              : const Text("Generate QR Backup"),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "📥 Restore dari QR",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "Jika PIN tidak dikenali di device ini, scan QR Backup "
                            "dari device utama untuk restore data.",
                        style: TextStyle(color: Colors.grey),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            // ✅ HANYA INI YANG DIPERBAIKI:
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => RestoreScreen(),
                              ),
                            );
                          },
                          icon: const Icon(Icons.upload_file),
                          label: const Text("Restore Sekarang"),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (_backupQr != null) ...[
                const SizedBox(height: 24),
                const Text(
                  "QR Backup (boleh di-screenshot):",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.white,
                    ),
                    child: Stack(
                      children: [
                        // ✅ INI YANG SALAH SEBELUMNYA — SEKARANG BENAR:
                        QrImageView(
                          data:_backupQr!, // ✅ NAMED PARAMETER, BUKAN POSISIONAL
                          size: 200,
                          backgroundColor: Colors.white,
                        ),
                        Positioned.fill(
                          child: Center(
                            child: Transform.rotate(
                              angle: -0.3,
                              child: Text(
                                "BACKUP",
                                style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.red.withOpacity(0.15),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "⚠️ QR ini hanya untuk restore ke device baru.\n"
                      "Jangan bagikan ke orang yang tidak dipercaya.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.red, fontSize: 12),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}