// lib/screens/session_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class SessionDetailScreen extends StatelessWidget {
  final String className;
  final String sessionId;
  final List<Map<String, dynamic>> absensi;

  const SessionDetailScreen({
    super.key,
    required this.className,
    required this.sessionId,
    required this.absensi,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text("Detail Sesi • $sessionId"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: absensi.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.person_off, size: 64, color: isDark ? Colors.grey : Colors.grey[600]),
            const SizedBox(height: 16),
            Text(
              "Tidak ada yang hadir",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : Colors.grey[700],
              ),
            ),
          ],
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: absensi.length,
        itemBuilder: (context, index) {
          final a = absensi[index];
          return ListTile(
            leading: const Icon(Icons.check, color: Colors.green),
            title: Text(a['name'] ?? '–'),
            subtitle: Text('NIM: ${a['nim'] ?? '–'}'),
          );
        },
      ),
    );
  }
}