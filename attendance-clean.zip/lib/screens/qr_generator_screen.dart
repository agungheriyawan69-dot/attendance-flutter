// lib/screens/qr_generator_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import '../providers/theme_provider.dart';
import '../services/database_service.dart';
import '../services/qr_service.dart';
import '../utils/string_utils.dart';
import 'package:qr_flutter/qr_flutter.dart';

class QrGeneratorScreen extends StatefulWidget {
  final String className;
  const QrGeneratorScreen({super.key, required this.className});

  @override
  State<QrGeneratorScreen> createState() => _QrGeneratorScreenState();
}

class _QrGeneratorScreenState extends State<QrGeneratorScreen> {
  final _db = DatabaseService();
  final _sessionController = TextEditingController();
  List<Map<String, dynamic>> _students = [];
  List<Map<String, dynamic>> _filteredStudents = [];
  String _searchQuery = '';
  String? _qrPayload;
  Timer? _expiryTimer;

  @override
  void initState() {
    super.initState();
    _loadStudents();
  }

  @override
  void dispose() {
    _expiryTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadStudents() async {
    final cleanClass = normalizeClassName(widget.className);
    final students = await _db.getStudents(cleanClass);
    if (mounted) {
      setState(() {
        _students = [...students]..sort((a, b) => a['name'].compareTo(b['name']));
        _filteredStudents = _students;
      });
    }
  }

  void _applySearch() {
    if (_searchQuery.isEmpty) {
      setState(() => _filteredStudents = _students);
    } else {
      final query = _searchQuery.toLowerCase();
      setState(() {
        _filteredStudents = _students.where((s) =>
        s['name'].toLowerCase().startsWith(query) ||
            s['nim'].toLowerCase().startsWith(query)
        ).toList();
      });
    }
  }

  void _generateQRForStudent(String nim, String name) {
    final sessionId = _sessionController.text.trim();
    if (sessionId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Session ID wajib diisi')),
      );
      return;
    }

    final cleanClass = normalizeClassName(widget.className);

    final payload = QRService.generateForStudent(
      classId: cleanClass,
      nim: nim,
      name: name,
      sessionId: sessionId,
    );

    setState(() => _qrPayload = payload);

    _db.createSession(cleanClass, sessionId);

    _expiryTimer?.cancel();
    _expiryTimer = Timer(Duration(seconds: QR_EXPIRY_SECONDS), () {
      if (mounted) setState(() => _qrPayload = null);
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text("QR Absen • ${widget.className}"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isDark
                ? [const Color(0xFF1E1E1E), const Color(0xFF0A0A0A)]
                : [const Color(0xFFF5F7FA), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(
                  "1. Isi Session ID (misal: Pertemuan 5)\n"
                      "2. Pilih mahasiswa dari daftar\n"
                      "3. QR akan muncul & berlaku 90 detik",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: isDark ? Colors.white70 : Colors.grey[600],
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _sessionController,
                  decoration: InputDecoration(
                    labelText: 'Session ID',
                    hintText: 'Contoh: Pertemuan 5 / UTS',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: const Color(0xFFE94E77)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: const Color(0xFFE94E77),
                        width: 2,
                      ),
                    ),
                  ),
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9_\- ]')),
                    LengthLimitingTextInputFormatter(MAX_SESSION_ID_LENGTH),
                  ],
                ),
                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _loadStudents,
                    child: const Text("Muat Daftar Student"),
                  ),
                ),
                const SizedBox(height: 20),

                TextField(
                  onChanged: (value) {
                    setState(() => _searchQuery = value);
                    _applySearch();
                  },
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search, color: Color(0xFFE94E77)),
                    hintText: 'Ketik awal nama atau NIM...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: const Color(0xFFE94E77)),
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                const Text('Pilih Student', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Expanded(
                  child: _filteredStudents.isEmpty
                      ? Center(child: Text(isDark ? 'Tidak ada yang cocok' : 'Tidak ada yang cocok'))
                      : ListView.builder(
                    itemCount: _filteredStudents.length,
                    itemBuilder: (context, index) {
                      final s = _filteredStudents[index];
                      return ListTile(
                        title: Text(s['name']),
                        subtitle: Text('NIM: ${s['nim']}'),
                        leading: const Icon(Icons.person, color: Color(0xFFE94E77)),
                        trailing: ElevatedButton(
                          onPressed: () => _generateQRForStudent(s['nim'], s['name']),
                          child: const Text("Generate QR"),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            backgroundColor: const Color(0xFFE94E77),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                        ),
                      );
                    },
                  ),
                ),

                if (_qrPayload != null) ...[
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        QrImageView(
                          data: _qrPayload!,
                          size: 200,
                          backgroundColor: Colors.white,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "QR berlaku $QR_EXPIRY_SECONDS detik",
                          style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}