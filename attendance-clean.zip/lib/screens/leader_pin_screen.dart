// lib/screens/leader_pin_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter/services.dart';
import '../providers/app_state.dart';
import '../screens/leader_dashboard.dart';
import '../screens/restore_screen.dart';
import '../providers/theme_provider.dart';

class LeaderPinScreen extends StatefulWidget {
  const LeaderPinScreen({super.key});

  @override
  State<LeaderPinScreen> createState() => _LeaderPinScreenState();
}

class _LeaderPinScreenState extends State<LeaderPinScreen> {
  final _pinController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final pin = _pinController.text.trim();

    final appState = context.read<AppState>();
    final className = await appState.verifyPinAndGetClass(pin);

    if (className == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("PIN salah atau tidak terdaftar")),
      );
      return;
    }

    await appState.setCurrentClass(className);

    // ✅ HANYA KIRIM className — tidak ada sessionId
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => LeaderDashboard(className: className),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(title: const Text("Verifikasi PIN")),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "Masukkan PIN Kelas Anda",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              TextFormField(
                controller: _pinController,
                decoration: InputDecoration(
                  labelText: "PIN",
                  hintText: "Contoh: 123456",
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: isDark ? Colors.amber : const Color(0xFFE94E77),
                      width: 2,
                    ),
                  ),
                ),
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(6),
                ],
                maxLength: 6,
                maxLengthEnforcement: MaxLengthEnforcement.enforced,
                validator: (value) {
                  if (value == null || value.isEmpty) return "PIN wajib diisi";
                  if (value.length != 6) return "PIN harus 6 digit";
                  return null;
                },
                onFieldSubmitted: (_) => _login(),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE94E77),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: _login,
                  child: const Text("Masuk ke Dashboard"),
                ),
              ),
              const SizedBox(height: 20),
              Divider(
                thickness: 1,
                color: isDark ? Colors.white30 : Colors.grey[300],
              ),
              const SizedBox(height: 16),
              TextButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const RestoreScreen(),
                    ),
                  );
                },
                icon: const Icon(Icons.qr_code, color: Color(0xFFE94E77)),
                label: const Text(
                  "Restore Kelas dari QR Backup",
                  style: TextStyle(color: Color(0xFFE94E77), fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}