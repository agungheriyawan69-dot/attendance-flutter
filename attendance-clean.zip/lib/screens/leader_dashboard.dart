// lib/screens/leader_dashboard.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import 'enrollment_screen.dart';
import 'history_screen.dart';
import 'export_pdf_screen.dart';
import 'qr_generator_screen.dart';
import 'backup_screen.dart';
import 'attendance_history.dart';

class LeaderDashboard extends StatelessWidget {
  final String className;

  const LeaderDashboard({
    super.key,
    required this.className,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text("Dashboard • $className"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
        actions: [
          IconButton(
            icon: Icon(isDark ? Icons.light_mode : Icons.dark_mode),
            onPressed: () {
              context.read<ThemeProvider>().toggleTheme();
            },
            tooltip: isDark ? 'Mode Terang' : 'Mode Gelap',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isDark
                ? [
              const Color(0xFF1E1E1E),
              const Color(0xFF121212),
              const Color(0xFF0A0A0A),
            ]
                : [
              const Color(0xFFE94E77),
              const Color(0xFFF5A623),
              const Color(0xFF20B2AA),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  decoration: BoxDecoration(
                    color: isDark ? Colors.white.withOpacity(0.1) : Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'Kelola Kelas Anda',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white70 : Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Expanded(
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 0.9,
                    children: [
                      _buildCard(
                        context,
                        icon: Icons.group_add,
                        label: "Enrollment",
                        subtitle: "Daftar siswa baru",
                        color: const Color(0xFF4A90E2),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => EnrollmentScreen(className: className),
                            ),
                          );
                        },
                      ),
                      _buildCard(
                        context,
                        icon: Icons.qr_code,
                        label: "QR Absen",
                        subtitle: "Mulai sesi absen",
                        color: const Color(0xFF9013FE),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => QrGeneratorScreen(className: className),
                            ),
                          );
                        },
                      ),
                      _buildCard(
                        context,
                        icon: Icons.calendar_today,
                        label: "📅 Riwayat Sesi",
                        subtitle: "Lihat & ulang sesi",
                        color: const Color(0xFF50E3C2),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => HistoryScreen(className: className),
                            ),
                          );
                        },
                      ),
                      _buildCard(
                        context,
                        icon: Icons.person_search,
                        label: "👥 Riwayat Siswa",
                        subtitle: "Pantau per siswa",
                        color: const Color(0xFF7B61FF),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => AttendanceHistoryScreen(className: className),
                            ),
                          );
                        },
                      ),
                      _buildCard(
                        context,
                        icon: Icons.save,
                        label: "Backup",
                        subtitle: "Restore ke device baru",
                        color: const Color(0xFF4A90E2),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => BackupScreen(className: className),
                            ),
                          );
                        },
                      ),
                      _buildCard(
                        context,
                        icon: Icons.picture_as_pdf,
                        label: "Export PDF",
                        subtitle: "Cetak laporan",
                        color: const Color(0xFFFFA500),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ExportPdfScreen(className: className),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCard(
      BuildContext context, {
        required IconData icon,
        required String label,
        required String subtitle,
        required Color color,
        required VoidCallback onTap,
      }) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: isDark ? Colors.black54 : Colors.black12,
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: color.withOpacity(isDark ? 0.2 : 0.15),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, size: 32, color: color),
              ),
              const SizedBox(height: 12),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF333333),
                ),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 12,
                  color: isDark ? Colors.white70 : const Color(0xFF666666),
                ),
                textAlign: TextAlign.center,
                maxLines: 1,
              ),
            ],
          ),
        ),
      ),
    );
  }
}