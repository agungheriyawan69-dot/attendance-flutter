// lib/screens/history_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/database_service.dart';

class HistoryScreen extends StatefulWidget {
  final String className;
  const HistoryScreen({super.key, required this.className});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _db = DatabaseService();
  List<Map<String, dynamic>> _sessions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    try {
      final data = await _db.getSessions(widget.className);
      if (mounted) {
        setState(() {
          _sessions = data;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Gagal memuat: $e")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context
        .watch<ThemeProvider>()
        .isDarkMode;
    return Scaffold(
      appBar: AppBar(
        title: Text("Riwayat Sesi • ${widget.className}"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _sessions.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: isDark ? Colors.grey.withOpacity(0.1) : Colors.grey[100],
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.history, size: 64,
                  color: isDark ? Colors.grey : Colors.grey[600]),
            ),
            const SizedBox(height: 16),
            Text(
              "Belum ada sesi absensi",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : Colors.grey[700],
              ),
            ),
            const SizedBox(height: 8),
            // ✅ Petunjuk ditempatkan di sini — di dalam body
            Text(
              "Buat sesi absen di menu QR Generator.\n"
                  "Setiap sesi otomatis tersimpan di sini.",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: isDark ? Colors.white70 : Colors.grey[600],
              ),
            ),
          ],
        ),
      )
          : RefreshIndicator(
        onRefresh: _loadHistory,
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: _sessions.length,
          itemBuilder: (context, index) {
            final session = _sessions[index];
            final createdAt = DateTime.tryParse(session['createdAt'] ?? '') ??
                DateTime.now();
            final formattedDate = '${createdAt.day}/${createdAt
                .month}/${createdAt.year}';
            final formattedTime = '${createdAt.hour.toString().padLeft(
                2, '0')}:${createdAt.minute.toString().padLeft(2, '0')}';

            return Card(
              color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                contentPadding: const EdgeInsets.all(16),
                leading: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: const Color(0xFF50E3C2).withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                      Icons.qr_code, color: const Color(0xFF50E3C2), size: 24),
                ),
                title: Text(
                  session['sessionId'] ?? 'Sesi Tanpa Nama',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : Colors.black,
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Dibuat: $formattedDate',
                      style: TextStyle(color: isDark ? Colors.white70 : Colors
                          .grey[600]),
                    ),
                    Text(
                      'Jam: $formattedTime',
                      style: TextStyle(color: isDark ? Colors.white70 : Colors
                          .grey[600]),
                    ),
                  ],
                ),
                trailing: Icon(Icons.arrow_forward_ios,
                    color: isDark ? Colors.white70 : Colors.grey[600],
                    size: 16),
                onTap: () async {
                  try {
                    final absensi = await _db.getAttendance(
                        widget.className, session['sessionId']);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            SessionDetailScreen(
                              className: widget.className,
                              sessionId: session['sessionId'],
                              absensi: absensi,
                            ),
                      ),
                    );
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Gagal: $e")));
                  }
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
class SessionDetailScreen extends StatelessWidget {
  final String className;
  final String sessionId;
  final List<Map<String, dynamic>> absensi;

  const SessionDetailScreen({
    super.key,
    required this.className,
    required this.sessionId,
    required this.absensi,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text("Detail Sesi • $sessionId"),
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        foregroundColor: isDark ? Colors.white : Colors.black,
      ),
      body: absensi.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: isDark ? Colors.grey.withOpacity(0.1) : Colors.grey[100],
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.person_off, size: 64, color: isDark ? Colors.grey : Colors.grey[600]),
            ),
            const SizedBox(height: 16),
            Text(
              "Tidak ada yang hadir",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : Colors.grey[700],
              ),
            ),
          ],
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: absensi.length,
        itemBuilder: (context, index) {
          final a = absensi[index];
          final ts = DateTime.tryParse(a['timestamp'] ?? '');
          final time = ts != null
              ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
              : '–';

          return Card(
            color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
            margin: const EdgeInsets.symmetric(vertical: 6),
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              leading: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.check, color: Colors.green, size: 20),
              ),
              title: Text(
                a['name'] ?? 'Tanpa Nama',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: isDark ? Colors.white : Colors.black,
                ),
              ),
              subtitle: Text(
                'NIM: ${a['nim'] ?? '–'} • $time',
                style: TextStyle(color: isDark ? Colors.white70 : Colors.grey[600]),
              ),
            ),
          );
        },
      ),
    );
  }
}