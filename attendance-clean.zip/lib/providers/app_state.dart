// lib/providers/app_state.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/pin_service.dart';

class AppState extends ChangeNotifier {
  late SharedPreferences _prefs;
  bool _isDark = false;
  String? _currentClass;

  AppState() {
    _init();
  }

  Future<void> _init() async {
    _prefs = await SharedPreferences.getInstance();
    _isDark = _prefs.getBool('isDarkMode') ?? false;
    _currentClass = _prefs.getString('current_class');
    notifyListeners();
  }

  bool get isDark => _isDark;
  String? get currentClass => _currentClass;

  Future<void> toggleTheme() async {
    _isDark = !_isDark;
    await _prefs.setBool('isDarkMode', _isDark);
    notifyListeners();
  }

  Future<void> setCurrentClass(String className) async {
    _currentClass = className;
    await _prefs.setString('current_class', className);
    notifyListeners();
  }

  // ✅ Verifikasi PIN → return className jika valid
  Future<String?> verifyPinAndGetClass(String pin) async {
    return PinService.instance.getClassByPin(pin);
  }

  // ✅ Cek apakah Leader sudah login
  bool get isLeaderLoggedIn => _currentClass != null;
}