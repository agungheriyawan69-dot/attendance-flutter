class Attendance {
  final int id;
  final int sessionId;
  final int studentId;
  final DateTime timestamp;

  Attendance({
    required this.id,
    required this.sessionId,
    required this.studentId,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'sessionId': sessionId,
    'studentId': studentId,
    'timestamp': timestamp.toIso8601String(),
  };

  factory Attendance.fromMap(Map<String, dynamic> m) => Attendance(
    id: m['id'],
    sessionId: m['sessionId'],
    studentId: m['studentId'],
    timestamp: DateTime.parse(m['timestamp']),
  );
}
