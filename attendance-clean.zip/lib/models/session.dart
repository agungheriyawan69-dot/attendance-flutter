class Session {
  final String className;
  final String sessionId;
  final DateTime createdAt;

  Session({
    required this.className,
    required this.sessionId,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'className': className,
    'sessionId': sessionId,
    'createdAt': createdAt.toIso8601String(),
  };

  factory Session.fromMap(Map<String, dynamic> m) => Session(
    className: m['className'],
    sessionId: m['sessionId'],
    createdAt: DateTime.parse(m['createdAt']),
  );
}
