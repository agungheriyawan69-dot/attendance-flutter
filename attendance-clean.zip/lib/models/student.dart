class Student {
  final int id;
  final String nim;
  final String name;
  final String className;

  Student({
    required this.id,
    required this.nim,
    required this.name,
    required this.className,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nim': nim,
      'name': name,
      'className': className,
    };
  }

  factory Student.fromMap(Map<String, dynamic> map) {
    return Student(
      id: map['id'],
      nim: map['nim'],
      name: map['name'],
      className: map['className'],
    );
  }
}
