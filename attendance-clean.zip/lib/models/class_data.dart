class ClassData {
  final int id;
  final String name;
  final String pin;

  ClassData({required this.id, required this.name, required this.pin});

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'pin': pin,
  };

  factory ClassData.fromMap(Map<String, dynamic> m) =>
      ClassData(id: m['id'], name: m['name'], pin: m['pin']);
}
