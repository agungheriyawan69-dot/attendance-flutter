class Leader {
  final String nim;
  final String name;

  Leader({required this.nim, required this.name});

  Map<String, dynamic> toMap() => {'nim': nim, 'name': name};

  factory Leader.fromMap(Map<String, dynamic> map) => Leader(nim: map['nim'], name: map['name']);
}
