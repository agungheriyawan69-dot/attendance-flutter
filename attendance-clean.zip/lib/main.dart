// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/date_symbol_data_local.dart' as intl;
import 'providers/theme_provider.dart';
import 'providers/app_state.dart';
import 'services/tts_service.dart';
import 'screens/role_selection.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await TtsService().speakWelcome();
  await intl.initializeDateFormatting('id_ID', null);

  runApp(const AttendanceApp());
}

class AttendanceApp extends StatelessWidget {
  const AttendanceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => AppState()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, _) {
          final isDark = themeProvider.isDarkMode;
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Attendance',
            theme: ThemeData(
              useMaterial3: true,
              colorScheme: ColorScheme.light(primary: const Color(0xFFE94E77)),
              scaffoldBackgroundColor: Colors.white,
              appBarTheme: const AppBarTheme(
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
              ),
            ),
            darkTheme: ThemeData.dark().copyWith(
              scaffoldBackgroundColor: const Color(0xFF121212),
              colorScheme: const ColorScheme.dark(primary: Color(0xFFE94E77)),
              appBarTheme: const AppBarTheme(
                backgroundColor: Color(0xFF121212),
                foregroundColor: Colors.white,
              ),
            ),
            themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
            home: const RoleSelectionScreen(), // ✅ TANPA className/sessionId
          );
        },
      ),
    );
  }
}