import 'package:flutter/material.dart';
import '../models/student.dart';


class StudentList extends StatelessWidget {
  final List<Student> students;
  const StudentList({super.key, required this.students});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: students.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (_, i) {
        final s = students[i];
        return ListTile(
          leading: const CircleAvatar(
            backgroundColor: Color(0xFFF1F5F9),
            child: Icon(Icons.person_outline, color: Color(0xFF334155)),
          ),
          title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text(s.nim),
        );
      },
    );
  }
}
