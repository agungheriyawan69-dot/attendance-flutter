// lib/widgets/qr_viewer_secure.dart
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:flutter/services.dart';

class QrViewerSecure extends StatefulWidget {
  final String data;
  final String? title;

  const QrViewerSecure({
    super.key,
    required this.data,
    this.title,
  });

  @override
  State<QrViewerSecure> createState() => _QrViewerSecureState();
}

class _QrViewerSecureState extends State<QrViewerSecure> {
  @override
  void initState() {
    super.initState();
    // 🔒 Aktifkan secure flag (native minimal)
    _setSecure(true);
  }

  @override
  void dispose() {
    _setSecure(false);
    super.dispose();
  }

  Future<void> _setSecure(bool secure) async {
    try {
      final channel = MethodChannel('secure_screen');
      await channel.invokeMethod('setSecure', secure);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (widget.title != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              widget.title!,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
          ),
          child: QrImageView(
            data: widget.data, // ✅ named parameter
            version: QrVersions.auto,
            size: 240,
          ),
        ),
        const SizedBox(height: 8),
        Text('Berlaku 90 detik'),
      ],
    );
  }
}