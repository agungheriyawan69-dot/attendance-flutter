import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/attendance.dart';
import '../models/student.dart';

class AttendanceList extends StatelessWidget {
  final List<Attendance> attendances;
  final List<Student> students;

  const AttendanceList({
    Key? key,
    required this.attendances,
    required this.students,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: attendances.length,
      itemBuilder: (context, index) {
        final attendance = attendances[index];
        // Cari student berdasarkan studentId
        final student = students.firstWhere(
              (s) => s.id == attendance.studentId,
          orElse: () => Student(id: 0, nim: '-', name: 'Unknown', className: '-'),
        );

        // Parsing timestamp → date + time
        final dateStr = DateFormat('dd/MM/yyyy').format(attendance.timestamp);
        final timeStr = DateFormat('HH:mm').format(attendance.timestamp);

        return ListTile(
          title: Text(student.name),
          subtitle: Text("${student.nim} - ${student.className}"),
          trailing: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(dateStr),
              Text(timeStr),
            ],
          ),
        );
      },
    );
  }
}
