# Attendance – Sistem Absensi Kelas Offline-First

![Flutter](https://img.shields.io/badge/Flutter-%2302569B?style=for-the-badge&logo=flutter&logoColor=white)
![Dart](https://img.shields.io/badge/Dart-%230175C2?style=for-the-badge&logo=dart&logoColor=white)
![Android](https://img.shields.io/badge/Android-%233DDC84?style=for-the-badge&logo=android&logoColor=white)

Sistem absensi berbasis kelas yang 100% offline, tanpa backend, hanya menggunakan penyimpanan lokal (`shared_preferences`). Cocok untuk sekolah/kampus yang tidak punya infrastruktur server.

## Fitur Utama
- ✅ Daftar siswa (NIM + nama)
- ✅ QR absen & QR backup kelas
- ✅ Restore kelas via scan QR (salin data antar HP)
- ✅ PIN kelas dengan dukungan multiple kelas per PIN
- ✅ Export PDF riwayat absen
- ✅ Dark/Light mode

## Teknologi
- Flutter 3.x + Dart 3.x
- `shared_preferences` untuk persistensi lokal
- `qr_flutter` & `mobile_scanner` untuk QR
- `pdf` + `printing` untuk export
- Architecture: Service-layer + Provider

## Cara Jalankan
```bash
flutter pub get
flutter run